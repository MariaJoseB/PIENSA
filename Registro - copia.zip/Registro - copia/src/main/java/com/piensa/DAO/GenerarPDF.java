/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.piensa.DAO;

import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Anchor;
import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chapter;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.List;
import com.itextpdf.text.ListItem;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Section;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.DottedLineSeparator;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Maria Jose
 */
public class GenerarPDF {
    private static final Font chapterFont = FontFactory.getFont(FontFactory.HELVETICA, 20, Font.BOLDITALIC);
    private static final Font paragraphFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL);
    private static final Font categoryFont = new Font(Font.FontFamily.TIMES_ROMAN, 18, Font.BOLD);
    private static final Font subcategoryFont = new Font(Font.FontFamily.TIMES_ROMAN, 16, Font.BOLD);
    private static final Font blueFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL, BaseColor.RED);
    private static final Font smallBold = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);
   // private static final String imagenn1 = "c://imgs//ui.png";
    
    
    public void CrearPdf (File archivoPDF) {
    try{
        Document documento = new Document();
            try{
            
                 PdfWriter.getInstance(documento, new FileOutputStream(archivoPDF));
        
            } catch (FileNotFoundException fileNotFoundException) {
                
              JOptionPane.showMessageDialog(null,"(No se encontró el fichero para generar el pdf)" + fileNotFoundException);
      
        }
             documento.open();
             Chunk titulo = new Chunk("~ CHILDHOOD ~", chapterFont);
            titulo.setBackground(BaseColor.PINK);
            Chunk titulo2 = new Chunk("Registros", categoryFont);
            titulo2.setBackground(BaseColor.WHITE);
            // Let's create de first Chapter (Creemos el primer capítulo)
            Paragraph parrafo = new Paragraph("Representante registrado ", paragraphFont);
            parrafo.setSpacingAfter(40);
            
            
            RegistroReDAO u = new RegistroReDAO();
            ArrayList<RegistroUsu> pdf = new ArrayList<>();
            pdf = u.listar();
            Integer numColumns = 8;

                                      // We create the table (Creamos la tabla).
            PdfPTable table = new PdfPTable(numColumns);
            // Ahora llenamos la tabla del PDF
            PdfPCell columnHeader;
            // rellenamos las filas de la tabla.
            columnHeader = new PdfPCell(new Phrase("Genero"));
            columnHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(columnHeader);

            columnHeader = new PdfPCell(new Phrase("Cedula"));
            columnHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(columnHeader);

            columnHeader = new PdfPCell(new Phrase("Nombre"));
            columnHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(columnHeader);
            
            columnHeader = new PdfPCell(new Phrase("Apellido"));
            columnHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(columnHeader);
            
            columnHeader = new PdfPCell(new Phrase("Cuidad"));
            columnHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(columnHeader);
            
            columnHeader = new PdfPCell(new Phrase("Genero"));
            columnHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(columnHeader);

            columnHeader = new PdfPCell(new Phrase("Edad"));
            columnHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(columnHeader);
            
            columnHeader = new PdfPCell(new Phrase("Telf."));
            columnHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(columnHeader);
            
           table.setHeaderRows(1);
          
            
            for (RegistroUsu tabla : pdf) {
                table.addCell(tabla.getCedu());
                table.addCell(tabla.getNom());
                table.addCell(tabla.getAp());
                table.addCell(tabla.getCuidad());
                table.addCell(tabla.getEmail());
                table.addCell(tabla.getGen());
                table.addCell(String.valueOf(tabla.getEdad()));
                table.addCell(String.valueOf(tabla.getTelf()));
            }
 /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 
            Paragraph parrafo2 = new Paragraph("Datos de niños registrados ", paragraphFont);
            parrafo2.setSpacingAfter(20);
            
            
            RegistroReDAO rep = new RegistroReDAO();
            ArrayList<Usuario> pdfni = new ArrayList<>();
            pdfni = rep.listarni();
            Integer numColumns2 = 7;

                                      // We create the table (Creamos la tabla).
            PdfPTable table2 = new PdfPTable(numColumns2);
            // Ahora llenamos la tabla del PDF
            PdfPCell columnHeader2;
            // rellenamos las filas de la tabla.
            columnHeader2 = new PdfPCell(new Phrase("Codigo"));
            columnHeader2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table2.addCell(columnHeader2);

            columnHeader2 = new PdfPCell(new Phrase("Nombre"));
            columnHeader2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table2.addCell(columnHeader2);

            columnHeader2 = new PdfPCell(new Phrase("Apellido"));
            columnHeader2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table2.addCell(columnHeader2);
           
            
            columnHeader2 = new PdfPCell(new Phrase("Edad"));
            columnHeader2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table2.addCell(columnHeader2);
            
            columnHeader2 = new PdfPCell(new Phrase("Escuelita"));
            columnHeader2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table2.addCell(columnHeader2);

            columnHeader2 = new PdfPCell(new Phrase("PalabraSeguridad"));
            columnHeader2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table2.addCell(columnHeader2);
            
            columnHeader2 = new PdfPCell(new Phrase("Genero"));
            columnHeader2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table2.addCell(columnHeader2);
            
            table2.setHeaderRows(1);
            
            for (Usuario tabla2 : pdfni) {
                table2.addCell(tabla2.getCodigo());
                table2.addCell(tabla2.getNombre());
                table2.addCell(tabla2.getApellido());
                table2.addCell(String.valueOf(tabla2.getEdad()));
                table2.addCell(tabla2.getEscuelita());
                table2.addCell(tabla2.getDulce());
                table2.addCell(tabla2.getGenero());
                
            }
            // Añadimos la tabla    
            // Añadimos el elemento con la tabla.
            
            documento.add(titulo);
            documento.add(titulo2);
            documento.add(parrafo);
            documento.add(table);
            documento.add(parrafo2);
            documento.add(table2);
            documento.close();
            
            System.out.println("Reporte generado exitosamente");
            JOptionPane.showMessageDialog(null,"Reporte genrado y descargado con exito");
            
        } catch(DocumentException documentException) {
    
            System.out.println("Error al generar el reporte): " + documentException);
            JOptionPane.showMessageDialog(null,"Error al generar reporte");
        }
          
            
  
            
 
    }
}    
