package com.piensa.DAO;


import com.mycompany.crud.Principal;
import com.mycompany.crud.VentanaUno;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Maria Jose
 */
public class RegistroReDAO extends ConexionRe {

    public void insertarUsuario(RegistroUsu registrousu) {
        try (Connection conection = connectToDB()) {
            PreparedStatement ps = null;
            //Statement statement = connection.createStatement();
            String query = "insert into usuariorep (usunombre, usuapellido,usucuidad,usuedad,usutelf, usuemail,usugenero,usucedu ) values (?,?,?,?,?,?,?,?)";
            ps = conection.prepareStatement(query);
            ps.setString(1, registrousu.getNom());
            ps.setString(2, registrousu.getAp());
            ps.setString(3, registrousu.getCuidad());
            ps.setInt(4, registrousu.getEdad());
            ps.setInt(5, registrousu.getTelf());
            ps.setString(6, registrousu.getEmail());
            ps.setString(7, registrousu.getGen());
            ps.setString(8, registrousu.getCedu());
            ps.executeUpdate();

            JOptionPane.showMessageDialog(null, "Registro exitoso");

        } catch (SQLException e) {

            e.printStackTrace();

        }

    }
    
    public void InsertarUsuarioNi (Usuario usuario){
        try (Connection connection = connectToDB()) {
            PreparedStatement ps = null;
            
            String query = "insert into representados(repcodigo,repnombre,repapellido,repedad,repescuelita,repdulce,repgenero)values (?,?,?,?,?,?,?)";
            ps = connection. prepareStatement(query);
            ps.setString(1,usuario.getCodigo());
            ps.setString(2,usuario.getNombre());
            ps.setString(3,usuario.getApellido());
            ps.setInt(4,usuario.getEdad());
            ps.setString(5,usuario.getEscuelita());
            ps.setString(6,usuario.getDulce());
            ps.setString(7,usuario.getGenero());
            ps.executeUpdate();
           
            
            JOptionPane.showMessageDialog(null,"Registro Exitoso :)");
            
        } catch(SQLException e){
            
           e.printStackTrace();
           
           JOptionPane.showMessageDialog(null,e);
        }
        }   

    public RegistroUsu inicioSesion (String Email,String Cedu) {
        RegistroUsu pref = new RegistroUsu();
        
        try (Connection connection = connectToDB()) {
            PreparedStatement ps = null;
            String query = "SELECT * FROM usuariorep where usucedu = ? and usuemail = ?"; //sentencia
            ps = connection.prepareStatement(query);
            ps.setString(1, Cedu);
            ps.setString(2, Email);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
            
           pref = new RegistroUsu (
            
                        rs.getString("usunombre"));
            
                    

            return pref;
            }
            
            
        
        } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null,"Cuenta no Existe" + e.getMessage());
            
            // TODO: handle exception
            
        }
                return null;
    }
     public void eliminar(String Cedu,String Email){
        try (Connection conection = connectToDB()) {
            PreparedStatement ps = null;
            String query = "delete from usuariorep where usucedu = ? and usuemail =?";
            ps = conection.prepareStatement(query);
            ps.setString(1,Cedu);
            ps.setString(2,Email);
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"La cuenta se elimino exitosamente");
        
       
        
        } catch (SQLException e) {
            
            e.printStackTrace();
            
            JOptionPane.showMessageDialog(null, "ERROR: "+e);
            
        }
       
    
    }
     
     public ArrayList<RegistroUsu> listar() {
        ArrayList<RegistroUsu> representantes = new ArrayList();

        try (Connection connection = connectToDB()) {
            String query = "SELECT * FROM usuariorep"; //sentencia
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet rs = preparedStatement.executeQuery();
        
            while (rs.next()) {
              RegistroUsu user = new RegistroUsu(
                        rs.getString("usucedu"),
                        rs.getString("usunombre"),
                        rs.getString("usuapellido"),
                        rs.getString("usucuidad"),
                        rs.getString("usuemail"),
                        rs.getString("usugenero"),
                      Integer.valueOf(rs.getString("usuedad")),
                      Integer.valueOf(rs.getString("usutelf"))
                );
                representantes.add(user);
            }
        } catch (SQLException e) {
            System.out.println("" + e.getMessage());
            // TODO: handle exception
        }
        return representantes;
    }
     public ArrayList<Usuario> listarni() {
        ArrayList<Usuario> representados = new ArrayList();

        try (Connection connection = connectToDB()) {
            String query = "SELECT * FROM representados"; //sentencia
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet ns = preparedStatement.executeQuery();
//repcodigo,repnombre,repapellido,repedad,repescuelita,repdulce,repgenero
            while (ns.next()) {
              Usuario user1 = new Usuario(
                      
                        ns.getString("repcodigo"),
                        ns.getString("repnombre"),
                        ns.getString("repapellido"),
                      Integer.valueOf(ns.getString("repedad")),
                        ns.getString("repescuelita"),
                        ns.getString("repdulce"),
                        ns.getString("repgenero")
                     
                );
                representados.add(user1);
            }
        } catch (SQLException e) {
            System.out.println("" + e.getMessage());
            // TODO: handle exception
        }
        return representados;
    }
     
     public Usuario Cod (String Codigo) {
        Usuario pf = new Usuario();
        
        try (Connection connection = connectToDB()) {
            
            PreparedStatement ps = null;
            String query = "SELECT * representados where repcodigo = ?"; //sentencia
            ps = connection.prepareStatement(query);
            ps.setString(1, Codigo);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
            
           pf = new Usuario (
            
                        rs.getString("repnombre"));
            
                    

            return pf;
            }
            
            
        
        } catch (SQLException e) {
            
            JOptionPane.showMessageDialog(null,"Niño no registrado" + e.getMessage());
            
            // TODO: handle exception
            
        }
                return null;
    }
}
