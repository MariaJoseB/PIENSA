package com.piensa.DAO;

/**
 *
 * @author Maria Jose
 */

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class ConexionRe {
   
    /*create table usuario (
  
   usunombre       varchar  (100)               not null,
   usuapellido       varchar  (100)               not null,
   usucuidad       varchar  (100)               not null,
   usuedad                SERIAL not null,
   usutelf               SERIAL not null,
   usuemail       varchar  (100)               not null,
   usugenero      varchar  (100)               not null,
	
    primary key (usuemail, usutelf)
);*/
   
    public Connection connectToDB() {
        
		Connection conection = null;
                
		String host = "ec2-52-204-20-42.compute-1.amazonaws.com";
                String db = "d5i9h7b72esa69";
                String pass ="3d617181069b46619c709e2f5c2a3a918e559f4e828773fcf19d6bbb5244c1d9";
                String Userr = "ffgxsmmyprxohl";
                
		try {
                   // Class.forName("org.postgresql.Driver");
			//conexionRe = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bdreg","postgres", "root1");
                        conection = DriverManager.getConnection("jdbc:postgresql://"+host+":5432/"+db,Userr,pass);
		//try {
                    //Class.forName("org.postgresql.Driver");
			//conection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bdreg","postgres", "root1");
			if (conection != null) {
                            
				//JOptionPane.showMessageDialog(null,"Se estableció la conexión");
			}
		} catch (Exception e) {
                    
                        JOptionPane.showMessageDialog(null,"Error al conectar a la base "+ e);
			e.printStackTrace();
                        
		}finally {
			return conection;
		}
		
	}
     
}
