
import java.sql.*;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maria Jose
 */


public class RegistroReDAO extends ConexionRe {
    
    public void insertarUsuario(RegistroUsu registrousu) {
        try (Connection conection = connectToDB()) {
            PreparedStatement ps = null;
            //Statement statement = connection.createStatement();
            String query = "insert into usuariore (usunombre, usuapellido,usucuidad,usuedad,usutelf, usuemail,usugenero,usucedu ) values (?,?,?,?,?,?,?,?)";
            ps = conection.prepareStatement(query);
            ps.setString(1, registrousu.getNom());
            ps.setString(2, registrousu.getAp());
            ps.setString(3, registrousu.getCuidad());
            ps.setInt(4,registrousu.getEdad());
            ps.setInt(5,registrousu.getTelf());
            ps.setString(6, registrousu.getEmail());
            ps.setString(7, registrousu.getGen());
            ps.setInt(8, registrousu.getCedu());
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"Registro exitoso");
            
        } catch (SQLException e) {
            
            e.printStackTrace();
            
           
    }
    
    
  
}
    }
