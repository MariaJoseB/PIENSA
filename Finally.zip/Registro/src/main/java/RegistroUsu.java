/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Maria Jose
 */
public class RegistroUsu {
    private String Nom, Ap, Cuidad,Email,Gen;
    private int Edad, Telf,Cedu;

    public RegistroUsu(String Nom, String Ap, String Cuidad, String Email, String Gen, int Edad, int Telf, int Cedu) {
        this.Nom = Nom;
        this.Ap = Ap;
        this.Cuidad = Cuidad;
        this.Email = Email;
        this.Gen = Gen;
        this.Edad = Edad;
        this.Telf = Telf;
        this.Cedu = Cedu;
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String Nom) {
        this.Nom = Nom;
    }

    public String getAp() {
        return Ap;
    }

    public void setAp(String Ap) {
        this.Ap = Ap;
    }

    public String getCuidad() {
        return Cuidad;
    }

    public void setCuidad(String Cuidad) {
        this.Cuidad = Cuidad;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getGen() {
        return Gen;
    }

    public void setGen(String Gen) {
        this.Gen = Gen;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    public int getTelf() {
        return Telf;
    }

    public void setTelf(int Telf) {
        this.Telf = Telf;
    }

    public int getCedu() {
        return Cedu;
    }

    public void setCedu(int Cedu) {
        this.Cedu = Cedu;
    }

    
    }
    
    
  
