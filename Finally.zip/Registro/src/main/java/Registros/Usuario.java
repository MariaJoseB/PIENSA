/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template    qwe in the editor.
 */
package Registros;

/**
 *
 * @author carolina
 */
public class Usuario {

   String Codigo;
   String Nombre; 
    String Apellido;
   int Edad;
    String Genero;
    String Escuelita;
   String Dulce;

    public Usuario(String Codigo, String Nombre, String Apellido, int Edad, String Genero, String Escuelita, String Dulce) {
        this.Codigo = Codigo;
        this.Nombre = Nombre;
        this.Apellido = Apellido;
        this.Edad = Edad;
        this.Genero = Genero;
        this.Escuelita = Escuelita;
        this.Dulce = Dulce;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String Codigo) {
        this.Codigo = Codigo;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String Apellido) {
        this.Apellido = Apellido;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String Genero) {
        this.Genero = Genero;
    }

    public String getEscuelita() {
        return Escuelita;
    }

    public void setEscuelita(String Escuelita) {
        this.Escuelita = Escuelita;
    }

    public String getDulce() {
        return Dulce;
    }

    public void setDulce(String Dulce) {
        this.Dulce = Dulce;
    }
   
   
   
}
    