/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Registros;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author carolina
 */
public class UsuarioDAO extends Conexion {

      
    public void InsertarUsuario (Usuario usuario){
        try (Connection connection = connectToDB()) {
            PreparedStatement ps = null;
            
            String query = "insert into representados(repcodigo,repnombre,repapellido,repedad,repescuelita,repdulce,repgenero)values (?,?,?,?,?,?,?)";
            ps = connection. prepareStatement(query);
            ps.setString(1,usuario.getCodigo());
            ps.setString(2,usuario.getNombre());
            ps.setString(3,usuario.getApellido());
            ps.setInt(4,usuario.getEdad());
            ps.setString(5,usuario.getEscuelita());
            ps.setString(6,usuario.getDulce());
            ps.setString(7,usuario.getGenero());
            ps.executeUpdate();
            
            JOptionPane.showMessageDialog(null,"Registro Exitoso");
            
        } catch(SQLException e){
            
           e.printStackTrace();
           
           JOptionPane.showMessageDialog(null,e);
        }
        }                 
    
    
  }
     
