/**
 *
 * @author Maria Jose
 */

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class ConexionRe {
   
    /*create table usuario (
  
   usunombre       varchar  (100)               not null,
   usuapellido       varchar  (100)               not null,
   usucuidad       varchar  (100)               not null,
   usuedad                SERIAL not null,
   usutelf               SERIAL not null,
   usuemail       varchar  (100)               not null,
   usugenero      varchar  (100)               not null,
	
    primary key (usuemail, usutelf)
);*/
   
    public Connection connectToDB() {
		Connection conection = null;
		
		try {
                    Class.forName("org.postgresql.Driver");
			conection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bdreg","postgres", "root1");
			if (conection != null) {
                            
				//JOptionPane.showMessageDialog(null,"Se estableció la conexión");
			}
		} catch (Exception e) {
                        JOptionPane.showMessageDialog(null,"Error al conectar a la base "+ e);
			e.printStackTrace();
		}finally {
			return conection;
		}
		
	}
     
}
